Code Reference
==========

afino_start
--------
.. automodule:: afino.afino_start
    :members:
       
afino_model_comparison
--------------------    
.. automodule:: afino.afino_model_comparison
    :members:

afino_main_analysis
----
.. automodule:: afino.afino_main_analysis3
    :members:

afino_model_fitting
---------------
.. automodule:: afino.afino_model_fitting
    :members:

afino_spectral_models
------------------
.. automodule:: afino.afino_spectral_models
    :members:

afino_utils
--------
.. automodule:: afino.afino_utils
    :members:

afino_series
--------
.. autoclass:: afino.afino_series
	       
.. automodule:: afino.afino_series
    :members: prep_series
